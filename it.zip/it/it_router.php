<?php
\Lang::addNamespace('it', base_path('app/it/lang'));
view()->addLocation(app_path('it/views'));
View::addNamespace('it', app_path('it/views'));

Route::get('/', function () {
		return it_views('welcome');
	});
Route::get('workflow', 'WorkFlow@loading');
