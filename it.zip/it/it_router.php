<?php

view()->addLocation(app_path('it/views'));

Route::get('/', function () {
		return view('it_links');
	});
Route::get('workflow', 'WorkFlow@loading');