<!DOCTYPE html>
<html>
	<head>
		<title>Welcome To It Program</title>
		<link rel="stylesheet" type="text/css" href="{{it_des('workflow_dist/css/bootstrap.css')}}" />
		<link rel="stylesheet" type="text/css" href="{{it_des('workflow_dist/css/bootstrap-theme.css')}}" />
		<script type="text/javascript" src="{{it_des('workflow_dist/js/jquery.min.js')}}"></script>
		<script type="text/javascript" src="{{it_des('workflow_dist/js/jquery-ui.min.js')}}"></script>
		<script type="text/javascript" src="{{it_des('workflow_dist/js/bootstrap.min.js')}}"></script>
	</head>
	<body>
	</body>
</html>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<nav class="navbar navbar-default" role="navigation">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
					</button> <a class="navbar-brand" href="{{url('it')}}">It Project</a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="activee">
							<a href="http://phpanonymous.com/it" target="_blank">It</a>
						</li>

						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">Tools<strong class="caret"></strong></a>
							<ul class="dropdown-menu">
								<li>
									<a href="{{url('it/workflow')}}">It Workflow</a>
								</li>

							</ul>
						</li>
					</ul>

				</div>
			</nav>
		</div>

		<hr />
		<div class="col-md-12">
			<div class="alert alert-info">
				<center><h1>Welcome To It Project (Test Version)</h1></center>

				Choose program in tools dropdown

			</div>






		</div>


<div class="footer">
<small>A simple track to make sense</small>
	<p class="pull-left">Copyright Reserved <a href="http://phpanonymous.com/it">it</a> &copy; {{date('Y')}} </p>
</div>
	</div>
</div>