<?php

namespace App\Console\Commands;

use Config;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use ZipArchive;

class ItComeOut extends Command {
	/**
	 * The name and signature of the console command.
	 *
	 * @var string
	 */
	protected $signature = 'it:hey {do}';
	protected $beer      = "\360\237\215\272";
	protected $ops       = "\xF0\x9F\x98\xB1";
	protected $like      = "\xF0\x9F\x91\x8D";
	protected $dislike   = "\xF0\x9F\x91\x8E";
	protected $love      = "\xF0\x9F\x98\x8D";
	protected $heart     = "\xE2\x9D\xA4";

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Install It by come-here or remove it by go-out Words';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function handle() {
		\Config::set('filesystems.default', 'it');
		$do = $this->argument('do');
		if ($do == 'come-here') {
			if (!class_exists('ZipArchive')) {
				$this->error("It".$this->beer."' tell you - you should be enable the ZipArchive Class On Your Apache To continue ");
				return '';
			}
			$this->line("It".$this->beer."' .::. prepare all files and cloning please wait...");
			shell_exec('git clone https://github.com/arabnewscms/it-come ');

			$zip = new ZipArchive;
			$res = $zip->open(base_path('it-come/it.zip'));
			if ($res === TRUE) {
				$zip->extractTo(base_path('app'));
				$zip->close();
			}

			$it_des = $zip->open(base_path('it-come/it_des.zip'));
			if ($it_des === TRUE) {
				$zip->extractTo(base_path('public'));
				$zip->close();
			}
			$itHelper = file_get_contents(base_path('it-come/it.php'));
			Storage::put('app/itHelpers/it.php', $itHelper);

			Storage::deleteDirectory('it-come');
			$this->line("It".$this->beer."' .::.  amazing i am ready now to assist you ".$this->love);

		} else if ($do == 'go-out') {
			if ($this->confirm('are you sure you want to delete (it) '.$this->ops.' ?')) {
				$this->line("It".$this->beer."' .::. omg i am sad but okay please wait to delete my files");
				$itHelper = file_get_contents(base_path('app/itHelpers/it.php'));
				Storage::put('app/itHelpers/it.php', '');
				Storage::deleteDirectory('app/it');
				Storage::deleteDirectory('public/it_des');
				$this->line("It".$this->beer."' .::. okay all is done Bye Bye :( ");
			} else {
				$this->line("It".$this->beer."' .::.  okay i am still here to assist you ".$this->love);
			}

		}
	}
}
