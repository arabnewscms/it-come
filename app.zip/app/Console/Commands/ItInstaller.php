<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class ItInstaller extends Command {
	/**
	 * The name and signature of the console command.
	 *
	 * @var string
	 */
	protected $signature = 'it:install {plugin?}';
	protected $beer      = "\360\237\215\272";
	protected $ops       = "\xF0\x9F\x98\xB1";
	protected $like      = "\xF0\x9F\x91\x8D";
	protected $dislike   = "\xF0\x9F\x91\x8E";
	protected $love      = "\xF0\x9F\x98\x8D";
	protected $heart     = "\xE2\x9D\xA4";
	protected $plugins   = ['merge', 'payment', 'editors', 'baboon'];
	protected $app       = "/* It Begin Providers Please don't remove this line */";
	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Install Environment & Plugins With (It)';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	}

	private function merge() {

		shell_exec('composer require barryvdh/laravel-elfinder');
		$elfinder_conf      = file_get_contents(base_path('app/it/configs/elfinder.php'));
		$elfindercontroller = file_get_contents(base_path('app/it/configs/elfindercontroller.it'));
		$app                = file_get_contents(base_path('config/app.php'));

		if (!preg_match('/Barryvdh\Elfinder\ElfinderServiceProvider::class/i', $app)) {
			$final = str_replace($this->app, $this->app."\r\n".'		Barryvdh\Elfinder\ElfinderServiceProvider::class ,', $app);
			\Storage::put('config/app.php', $final);
			$this->info('It'.$this->beer.' the provider Barryvdh\Elfinder\ElfinderServiceProvider::class auto inserted in providers');

		}

		//shell_exec("php artisan vendor:publish --provider='Barryvdh\Elfinder\ElfinderServiceProvider' --tag=config");
		shell_exec("php artisan vendor:publish --provider='Barryvdh\Elfinder\ElfinderServiceProvider' --tag=views");
		shell_exec("php artisan elfinder:publish");
		$this->info('It'.$this->beer.' Elfinder Published Environments');
		\Storage::put('config/elfinder.php', $elfinder_conf);
		$this->info('It'.$this->beer.' Elfinder Config generated to config/elfinder.php');
		\Storage::put('vendor/barryvdh/laravel-elfinder/src/ElfinderController.php', $elfindercontroller);
		$this->info('It'.$this->beer.' Elfinder Auto Configured By (It) - (it merge) Now Is ready to you   '.$this->love);

	}

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function handle() {
		\Config::set('filesystems.default', 'it');

		//$this->option('plugin');
		$plugin = $this->argument('plugin');
		if (in_array($plugin, $this->plugins)) {
			if ($plugin == 'merge') {
				$this->info('It'.$this->beer.' preparing file system merge');
				$this->merge();

			}
		} else {
			$plugg = [];

			$this->error('It'.$this->beer.' Ops Choose Plugin From List ');
			$headers = [
				'Command (php artisan it:install)',
				'Description'
			];
			foreach ($this->plugins as $plug) {
				if ($plug == 'merge') {
					$title = 'A Controller File Project to merge your files';
				} elseif ($plug == 'payment') {
					$title = 'Payment Getway trusted Packages Paypal,Cashu,payfort & much more ... ';
				} elseif ($plug == 'editors') {
					$title = 'Ckeditor,NiceEdit,jWYSIWYG,summernote,react-rte & much more ...  ';
				} elseif ($plug == 'baboon') {
					$title = 'Baboon CRUD System Created By Mahmoud Ibrahim v1';
				}
				array_push($plugg, [$plug, $title]);
			}
			$this->table($headers, $plugg);
		}
	}
}
