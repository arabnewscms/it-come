<?php
\Lang::addNamespace('it', base_path('app/it/lang'));
view()->addLocation(app_path('it/views'));
\View::addNamespace('it', app_path('it/views'));

Route::group(['namespace' => 'App\it\Controllers'], function () {

		Route::get('/', function () {
				return it_views('welcome');
			});
		Route::get('workflow', 'WorkFlow@loading');
		if (class_exists('Barryvdh\Elfinder\Session\LaravelSession')) {
			Route::get('merge', 'Merge@merge');
		}
	});

//////// Elfinder Configurations Routes ///////////////
$config['namespace'] = 'Barryvdh\Elfinder';

Route::group($config, function () {

		Route::any('connector', ['as'             => 'elfinder.connector', 'uses'             => 'ElfinderController@showConnector']);
		Route::get('popup/{input_id}', ['as'      => 'elfinder.popup', 'uses'      => 'ElfinderController@showPopup']);
		Route::get('filepicker/{input_id}', ['as' => 'elfinder.filepicker', 'uses' => 'ElfinderController@showFilePicker']);
		Route::get('tinymce', ['as'               => 'elfinder.tinymce', 'uses'               => 'ElfinderController@showTinyMCE']);
		Route::get('tinymce4', ['as'              => 'elfinder.tinymce4', 'uses'              => 'ElfinderController@showTinyMCE4']);
		Route::get('ckeditor', ['as'              => 'elfinder.ckeditor', 'uses'              => 'ElfinderController@showCKeditor4']);
	});
//////// Elfinder Configurations Routes ///////////////