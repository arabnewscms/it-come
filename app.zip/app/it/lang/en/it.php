<?php
return [
	'home'             => 'Welome To It',
	'it'               => 'It Program',
	'version'          => 'Version',
	'slug'             => 'A simple track to make sense',
	'welcome'          => 'Welcome To It Project (Test Version)',
	'programs'         => 'It Programs & Tools',
	'workflow'         => 'It Workflow',
	'feat_tools'       => 'Features / Tools',
	'home_page'        => 'It Home Page',
	'document_online'  => 'Online Document',
	'document_offline' => 'Offline Document',
	'have_bugs'        => 'have A Bugs ? Please Tell me to fix (it) Quickly ',
	'send_now'         => 'Send Quickly ',
	'much_more'        => 'Much more',
	'merge'            => 'It Merge',
];