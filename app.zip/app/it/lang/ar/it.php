<?php
return [
	'it' => 'برنامج It',
];