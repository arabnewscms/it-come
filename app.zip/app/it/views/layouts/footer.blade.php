</div>
<div class="col-md-4 hidden-xs hidden-sm">
	<br>
	<br>
	<br>
<div class="panel panel-default">
    <div class="bs-callout bs-right-panel">
        <div class="row">
            <h3 class="text-primary">{{it_trans('it.slug')}}</h3>
        </div>
        <div class="row">
            <p class="text-center">Copyright Reserved <a href="http://phpanonymous.com/it">it</a> &copy; {{date('Y')}} {{it_trans('it.version')}}{{it_version()}} </p>
        </div>
    </div>
</div>
</div>
</div>
</div>
</body>
</html>