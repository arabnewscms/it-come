@include('layouts.header')

@yield('it')

@include('layouts.footer')