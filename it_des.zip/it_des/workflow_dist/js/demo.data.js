
var demoData = {	
	
	contactTypes: [
			{Id: 1, name:"Call", icon:"glyphicon-earphone"},
			{Id: 2, name:"Mailing", icon:"glyphicon-envelope"},
			{Id: 3, name:"Appointment", icon:"glyphicon-calendar"},
			{Id: 4, name:"Email", icon:"glyphicon-globe"},
			{Id: 5, name:"Other", icon:"glyphicon-file"}
	],
	
	userTypes: [
			{Id: 1, name:"All Agency Users"},
			{Id: 2, name:"Full Time"},
			{Id: 3, name:"Agent - Full Time"}
	],
	
	templates: [
			{Id:1, name:"Save More"},
			{Id:2, name:"Protect Your Business"},
			{Id:3, name:"Optional Auto"},
			{Id:4, name:"Don't Miss Out"},
			{Id:5, name:"Family's Insurance Needs"},
			{Id:6, name:"Own Your Own Business"},
			{Id:7, name:"Protect Your Family"},
			{Id:8, name:"Essential Life"},
			{Id:9, name:"Things Change"},
			{Id:10, name:"We're with you all the way"}
	]

};


